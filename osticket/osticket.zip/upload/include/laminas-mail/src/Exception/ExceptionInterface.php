<?php

namespace Laminas\Mail\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
